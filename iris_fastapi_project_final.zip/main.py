
from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import joblib

app = FastAPI()

class IrisInput(BaseModel):
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float

model = joblib.load("iris_model.pkl")
species = ['setosa', 'versicolor', 'virginica']

@app.get("/")
def read_root():
    return {"message": "Iris Prediction API is Live!"}

@app.post("/predict")
def predict_species(data: IrisInput):
    features = np.array([[data.sepal_length, data.sepal_width, data.petal_length, data.petal_width]])
    prediction = model.predict(features)
    return {"predicted_species": species[prediction[0]]}
